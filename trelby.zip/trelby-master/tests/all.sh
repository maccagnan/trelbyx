#!/bin/bash

export TRELBY_TESTING=1

./do_tests.py --file-at-a-time
